% Copyright (C) 2019 Veith Weilnhammer, CCM55
clear all
close all

%% Control fMRI Experiment

root_dir = 'C:\Users\bcanguest\Documents\PsychToolbox Experiments\AG_STERZER\Veith\parametric_RDK\Experimental_Scripts\Experimental_Scripts_fMRI_Control\'; % root directory for settings and results
root_dir_main = 'C:\Users\bcanguest\Documents\PsychToolbox Experiments\AG_STERZER\Veith\parametric_RDK\Experimental_Scripts\Experimental_Scripts_fMRI\' % directory for main experiment (used to load balance betwen perceptual outcomes

BlueValue = '200' % Put in Blue Value from Heterochromatic flicker photometry

RedValue = '100'

ObserverName= 'fMRI_PE_observer_014' % Name of the observer

SettingsName= 'C_pRDK'; % points to Settings file

which_run = 0; %R0: dummy run for trying different settings; CR1 control run


%%
%%
%% Run 0 (Test + Tryout):

if which_run == 0
    session= ['run_' num2str(which_run)]
    run_idx = which_run;
    
    %% load data from main experiment
    load(fullfile(root_dir_main, 'Results', ['Results_' ObserverName '_Conv.mat']))
    transition_probability = nanmean(nanmean(frequency(:,[1])))
    balance = [nanmean(correct(:,2:end),2)]' % temporal balance between perceptual interpretations. 0.5: complete balance; 1: complete imbalance;
    
    [Results] = presentation_C_pRKD(root_dir, SettingsName, ObserverName, BlueValue, RedValue, session, balance, transition_probability); % run presentation
    [control_frequency control_correct] = get_conventional_control_data(Results); 
end

%%
%%
%% Control Run 1:
if which_run == 1
    session= ['run_' num2str(which_run)]
    run_idx = which_run;
    
    %% load data from main experiment
    load(fullfile(root_dir_main, 'Results', ['Results_' ObserverName '_Conv.mat']))
    transition_probability = nanmean(nanmean(frequency(:,[1])))
    balance = [nanmean(correct(:,2:end),2)]' % temporal balance between perceptual interpretations. 0.5: complete balance; 1: complete imbalance;
    [Results] = presentation_C_pRKD(root_dir, SettingsName, ObserverName, BlueValue, RedValue, session, balance, transition_probability); % run presentation
  
    %% analysis
    [control_frequency(:,run_idx) control_correct(:,run_idx)] = get_conventional_control_data(Results);
    save([root_dir  'Results/Results_' ObserverName '_Control_Conv.mat'], 'control_frequency', 'control_correct');
    
end